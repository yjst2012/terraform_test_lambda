def handler(event, context):
    return { "message": "Hello, World!" }

def post_handler(event, context):
    return { "message": "something has been posted..." }
